var fields = new Array();
var errorstr = new Array();
var showStyle = 1;

//===================����Ϊ������ʾ����

errorstr[10] = msgInputIsNotNull;
errorstr[11] = msgIllegalFormat;
errorstr[12] = msgMonthOutRange;
errorstr[13] = msgStringOutRange;
errorstr[14] = msgInvalidNumberFormat;
errorstr[15] = msgNumberTooBig;
errorstr[16] = msgNumberTooSmall;
errorstr[17] = msgNumorDecimalTooLong;
errorstr[18] = msgNotValidNumber;
errorstr[19] = msgInputCorrectEmail;
errorstr[20] = msgDateOutRange;
errorstr[21] = msgYearOutRange;
errorstr[22] = msgValidMail;
errorstr[23] = msgUserNameTooLong;
errorstr[24] = msgNoSymbol;
errorstr[25] = msgChineseOnly;
errorstr[26] = msgHourOutRange;
errorstr[27] = msgMinOutRange;
errorstr[28] = msgSecondOutRange;
errorstr[29] = msgInvalidIpAddress;



//===================����Ϊ������������
//ckdoc����Ϊwindows object
function checkval(ckdoc)
{ 
	// ���fields�еı���
  	var i;
  	var iscorrect = true;
  	var isitemcorrect = 1;
  	var elvalue = null;
  	var alertstr = "";

  	for(i=0;i<fields.length;i++)
  	{
    		isitemcorrect = true;
    		fields[i].val = "";

    		if(fields[i] != null && fields[i].name != null)
    		{
      			if(ckdoc.document.all(fields[i].name) == null) 
      			{
          			continue;
						}
						else
						{
				  		elvalue = Trim(ckdoc.document.all(fields[i].name).value);
				  		ckdoc.document.all(fields[i].name).value = elvalue;
						}
    		}
    		else{
      			continue;
    		}
      	if(elvalue == null || elvalue == "")
    		{
      			if(fields[i].defaultval != null && fields[i].defaultval != "") 
      			{
      	  		elvalue = ckdoc.document.all(fields[i].name).value = fields[i].defaultval;
      			}
      			if(fields[i].isnull)
      			{
      			continue;
      			}
      			else
      			{
      				alertstr += '[' + fields[i].cnname + ']' + errorstr[10] + '!\n';
        			iscorrect = false;
        			continue;
      			}
    		}
		//��֧����ж����ͱ���'type'
    		switch(fields[i].type)
    		{
      		case 'c'  :
        		isitemcorrect = IsChar(elvalue,fields[i].len1);
        		break;
        
      		case 'ch' :
      			isitemcorrect = IsChinese(elvalue,fields[i].len1);
      			break;
      	
      		case 'i'  :
        		isitemcorrect = IsInt(elvalue,fields[i].len1);
        		if(isitemcorrect == 1)
        		isitemcorrect = compval(elvalue,fields[i]);
      			break;
      			
      		case 'l'  :
        		isitemcorrect = Islong(elvalue,fields[i].len1);
        		if(isitemcorrect == 1)
        		isitemcorrect = compval(elvalue,fields[i]);
      			break;
        
      		case 'd'  :
      			isitemcorrect = IsDouble(elvalue,fields[i].len1,fields[i].len2);
       			if(isitemcorrect == 1)
        		isitemcorrect = compval(elvalue,fields[i]);
        		break;
        	
        	case 'f'  :
      			isitemcorrect = Isfloat(elvalue,fields[i].len1,fields[i].len2);
       			if(isitemcorrect == 1)
        		isitemcorrect = compval(elvalue,fields[i]);
        		break;
        
      		case 'ip' :
      			isitemcorrect = IsIp(elvalue,fields[i].len1);
        		break;
        
      		case 'u' :
      			isitemcorrect = IsUrl(elvalue,fields[i].len1);
        		break;
        
      		case 'uu' :
      			isitemcorrect = IsUpLoadUrl(elvalue,fields[i].len1);
      			break;
        
      		case 'dt'  :
        		isitemcorrect = checkDateTimeFormat(elvalue,fields[i].format,fields[i].type);
						break;
	
      		case 'ib' :
      			isitemcorrect = IsBach(elvalue,fields[i].len1);
      			break;
	
      		case 'm'  :
						isitemcorrect = IsMail(elvalue,fields[i].len1);
						break;
	
      		default	  :
						isitemcorrect = 0;
    		}
    		if(isitemcorrect != 1)
    		{
      			alertstr += '[' + fields[i].cnname + ']' + errorstr[isitemcorrect] +  '!\n';
      			iscorrect = false;
      
    		}
    		else
    		{
      			fields[i].val = elvalue;
    		}
      
  	}
  	if(!iscorrect)
  	{
      		showMessage(alertstr);
		}
  	fields = new Array();
  	return iscorrect;
}

//����Ԥ�����
function addfield(name,cnname,type,isnull,len1,len2,minval,maxval,format,defaultval)
{
  	var len = fields.length;
  	fields[len] = new Object;
  	fields[len].name = name;
  	fields[len].cnname = cnname;
  	fields[len].type = type; 
  	fields[len].isnull = isnull;
  	fields[len].len1= len1;   	
  	fields[len].len2= len2;	
  	fields[len].minval=minval;
  	fields[len].maxval=maxval;
  	fields[len].format=format;
  	fields[len].defaultval=defaultval;
  	
	/*-- Types are 'c','ch','d','i','ip','t','dt','tt','u','uu','m' 
	     'm' represents email,
	     'ch' represents chinese input
	     'u' represents URL 
	     'uu' represent Upload URL
	     'c','i','t','dt','tt','ip','u','uu' use len1 and 'd'use len1 and len2 --*/
}    

//===================����Ϊ�����߼����� 					
function isSpace(val) 
{
  	return isEmpty(removeSpace(val));
}

//�ж��Ƿ�Ϊ��
function isEmpty(val)
{
	if (val == "")
	{
    		return true;
  	} 
  	else 
  	{
    		return false;
  	}
}

//�ж��Ƿ�Ϊ�Ϸ��û���
function IsChar(val,len)
{	
	Reg=/^\w+$/g;
	if(val.length>len)
		return 23;
  	if(val.match(Reg))
		return 1;
	return 24;
  		
}

//�ж��Ƿ�Ϊ��������
function IsInt(val,len)
{	
  	if(isNaN(val)) 
  		return 14;
  	
  	else if(val.indexOf(".") != -1) 
  	
  		return 18;
  		
  	if(val.length<=len) 
  		return 1;
  	return 15;
}

//�ж��Ƿ�Ϊ����������,���ӿڣ���intһ��
function Islong(val,len)
{
  	return Isint(val,len);
}

//�ж��Ƿ�Ϊ��������
function IsDouble(val,len1,len2)
{
  	if(isNaN(val)) 
  		return 14;
  	Reg=/^\-{0,1}\d+\.\d+$/g;
  	if(!val.match(Reg))
  		return 11;
	if(val.indexOf(".")<0)
  	{
    		if(val.length<=len1) 
    			return 1;
    		return 15;
    	}
  	if(val.substring(0,val.indexOf(".")).length > len1)
  		return 15;
  	 if(val.length-val.indexOf('.')-1 <= len2)
    		return 1;
  	return 17;
}

//�ж��Ƿ�Ϊ�������֣����ӿڣ���doubleһ��
function Isfloat(val,len1,len2)
{
  return Isdouble(val,len1,len2);
}

//�ж��Ƿ񳬹����к͸������ֵĴ�С��Χ
function compval(val1,val2)
{
  	if(val2 == null || val2 == '') 
    		return 1;
    	var val11 = parseFloat(val1);
  	if(val2.maxval != null && val2.maxval != '')
    		if(val11 - val2.maxval > 0.00001)
    		return 15;
  	if(val2.minval != null && val2.minval != '')
    	if(val11 - val2.minval < -0.00001)
      		return 16;
  	return 1;
}

//�ж��Ƿ�Ϊ��Ч��ʱ��/���ڸ�ʽ
function checkDateTimeFormat(dt,fm,type)
{
	if(dt.length>fm.length){
         	return 13;
    	}
    	if(dt.length<fm.length){
    		return 16;
    	}
    	else
    	{
         	var dt1=dt.replace(/[0-9]/g,"%d");
         	var dt2=fm.replace(/[ymdhsa]/gi,"%d");
         	if(dt1!=dt2){
               		return 11;
         	}
    	}

	try
	{
     		fm=fm.replace(/Y/g,"y").replace(/D/g,"d");
     		var iyyyy=fm.indexOf("yyyy");
     		var iyy=fm.indexOf("yy");
     		var imm=fm.indexOf("MM");
     		var idd=fm.indexOf("dd");
     		var ihh=fm.indexOf("hh");
     		var imi=fm.indexOf("mm");
     		var iss=fm.indexOf("ss");
     		var iaa=fm.indexOf("aaa");
		var newdt=new Date();
     		newdt.setYear("2000");
     		newdt.setDate("01");
     		newdt.setMonth("01");
		var year="";
     		//�ж��Ƿ�Ϊ��Ч���������
     		try
     		{
         		var isyear=false;
         		if(iyyyy>-1){
         			year=dt.substr(iyyyy,4);
         			if(year<1950||year>2100)//������Ա���趨�˷�Χ
            				return 21;
            			isyear=true;
        		}
         		else if(iyy>-1){
           			year=dt.substr(iyy,2);
            			isyear=true;
         		}
         		if(isyear){
            			if(type=="1"){
              				year=parseInt(year)+1911;
           			}
            		newdt.setFullYear(year);
         		}
     		}
     		catch(e1){
         		return false;
     		}
	 //�ж��Ƿ�Ϊ��Ч����������
	 if(newdt.getMonth() != 1)
	 {
     		try
     		{
         		if(idd>-1)
         		{
             			if(dt.substr(idd,2)>"31"||dt.substr(idd,2)<"01"){
                 			return 20;
             			}
             		newdt.setDate(dt.substr(idd,2));
        		}
     		}
     		catch(e1){
         		return false;
     		}

     		//�ж��Ƿ�Ϊ��Ч���·�����
     		try
     		{
         		if(imm>-1)
         		{
             			if(dt.substr(imm,2)>"12"||dt.substr(imm,2)<"01"){
                 			return 12;
             			}
             		newdt.setMonth(dt.substr(imm,2)-1);
         		}
     		}
     		catch(e1){
         	return false;
     		}
    	}
	else
	{
	 	//��ͬ��ʽ���ж��Ƿ�Ϊ��Ч���·�����
     		try
     		{
         		if(imm>-1)
         		{
             			if(dt.substr(imm,2)>"12"||dt.substr(imm,2)<"01"){
                 			return 12;
             			}
             		newdt.setMonth(dt.substr(imm,2)-1);
         		}
     		}
     		catch(e1){
         		return false;
     		}
	 	//��ͬ��ʽ���ж��Ƿ�Ϊ��Ч����������
	 	try
	 	{
         		if(idd>-1)
         		
         		{
             			if(dt.substr(idd,2)>"31"||dt.substr(idd,2)<"01"){
                 			return 20;
             			}
             		newdt.setDate(dt.substr(idd,2));
         		}
     		}
     		catch(e1){
         		return false;
     		}
	}

     	//�ж��Ƿ�Ϊ��Ч��Сʱ����
     	try
     	{	
         	if(ihh>-1){
             		if(dt.substr(ihh,2)>"23"){
                 		return 26;
             		}
             	newdt.setHours(dt.substr(ihh,2));
         	}
    	}
     	catch(e1){
         	return false;
     	}

     	//�ж��Ƿ�Ϊ��Ч�ķ�������
     	try
     	{
         	if(imi>-1){
             		if(dt.substr(imi,2)>"59"){
                 		return 27;
             		}
            	newdt.setMinutes(dt.substr(imi,2));
         	}
     	}
     	catch(e1){
         	return false;
     	}

     	//�ж��Ƿ�Ϊ��Ч����������
     	try
     	{
         	if(iss>-1){
             		if(dt.substr(iss,2)>"59"){
                 		return 28;
             		}
             	newdt.setSeconds(dt.substr(iss,2));
        	}
     	}
     	catch(e1){
         	return false;
     	}
     	//�ж��Ƿ�Ϊ��Ч�ĺ�������
     	try
     	{
         	if(iaa>-1){
             		if(dt.substr(iaa,2)>"999"){
                 		return 11;
             		}
            	newdt.setMilliseconds(dt.substr(iaa,2));
         	}
     	}
     	catch(e1){
         	return false;
     	}

     	//�������Ƿ����Ԥ���ʽ
     	if(iyyyy>-1){
          	if(newdt.getFullYear()!=year){
                 	return 11;
          	}
     	}
     	else if(iyy>-1){
          	if(newdt.getFullYear()!=year){
                 	return 11;
          	}
     	}

      	//��������Ƿ����Ԥ���ʽ
     	if(idd>-1){
          	if(newdt.getDate()!=dt.substr(idd,2)){
                 	return 20;
          	}
     	}

     	//����·��Ƿ����Ԥ���ʽ
     	if(imm>-1){
          	if(newdt.getMonth()!=(dt.substr(imm,2)-1)){
                	return 11;
         	}
    	}

     	//���Сʱ�Ƿ����Ԥ���ʽ
     	if(ihh>-1){
          	if(newdt.getHours()!=dt.substr(ihh,2)){
                 	return 11;
          	}
     	}

     	//��������Ƿ����Ԥ���ʽ
     	if(imi>-1){
          	if(newdt.getMinutes()!=dt.substr(imi,2)){
                 	return 11;
          	}
     	}

     	//��������Ƿ����Ԥ���ʽ
     	if(iss>-1){
          	if(newdt.getSeconds()!=dt.substr(iss,2)){
                	return 11;
          	}
     	}
     	//��������Ƿ����Ԥ���ʽ
     	if(iaa>-1){
          	if(newdt.getMilliseconds()!=dt.substr(iaa,2)){
               	return 11;
          	}
     	}
     	return true;
	}
	catch(e){
     		return false;
	}
}


function LTrim(str)
{
	var whitespace = new String(" \t\n\r");
	var s = new String(str);
	if (whitespace.indexOf(s.charAt(0)) != -1)
	{
		var j=0, i = s.length;
		while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
		{
			j++;
		}
		s = s.substring(j, i);
	}
	return s;
}

function RTrim(str)
{
	var whitespace = new String(" \t\n\r");
	var s = new String(str);
	if (whitespace.indexOf(s.charAt(s.length-1)) != -1)
	{
		var i = s.length - 1;
		while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
		{
			i--;
		}
		s = s.substring(0, i+1);
	}
	return s;
}


function Trim(str)
{
	return RTrim(LTrim(str));
}

//�ж��Ƿ�Ϊ��Ч���ϴ���ַ
function IsUpLoadUrl(str)
{
	Reg = /^([a-z]|[A-Z]){1}:\\([^\n\r\f\\\/:\*\?\"<>\|]+\\)*[^\n\r\f\\\/:\*\?\"<>\|]+\.(\D{1,4})$/
	if (Reg.exec(str))
	{
		return true;
		}
	else{
		return 11;
		}
}

function IsEmpty(str)
{
	if (Trim(str).length == 0){
		return true;
	}
	return false;
}

//�ж������ַ��Ƿ�Ϊ����
function IsChinese (str,len) 
{	
	if(str.length>len)
		return 13;
	Reg = /[^\u4e00-\u9fa5]/
	if (!IsEmpty(str))
	{
		if (str.match(Reg)){
			return 25;
		}
		return true;
	}
	return false;
}

//�ж��Ƿ�Ϊ��Ч���ʼ���ַ
function IsMail (str, len) 
{	
	if(str.length>len)
		return 13;
	Reg = /^\w+@\w+((\.\w{2,})|((\.\w{2,})(\.\D{2})))$/g;
	if (str.match(Reg)) {
		return true;
		}
	if(str.indexOf("@")<0)
		return 22;
	if(str.indexOf(".")<0)
		return 22;
	if(str.indexOf(" ")>0||str.indexOf(" ")<0)
		return 19;
	
	return 24;
}

//�ж��Ƿ�Ϊ��Ч��IP��ַ
function IsIp (str,len)
{		
	if(str.length>len)
	return 13;
	Reg1 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/g;
	if(str.match(Reg1)){
	
		Reg = /^([1-9]{1}|[1-9]{1}\d{1}|[1]{1}\d{2}|[2]{1}[0-5]{1}\d{1})(\.([0-9]{1}|[1-9]{1}\d{1}|[1]{1}\d{2}|[2]{1}[0-5]{1}\d{1})){3}$/g
	
		if (str.match(Reg))
		{
			ip=str.split(".");
			var ipnum = 0;
			for (i=0; i<ip.length;i++)
			{
			ipnum += ip[i]*Math.pow(255,(ip.length-1-i));
			}
			if (IsBach(ipnum,0,4244897280)){
				return true;
			}
		}return 29;
	}return 24;
	
}

//�Ƚ�IP��ַ�������Сֵ
function IsBach(num,minnum,maxnum)
{
	if (IsNum(num) && IsNum(minnum) && IsNum(maxnum)){
		if ((num>=minnum) && (num<=maxnum)){
			return true;
		}
			
	}
	return false;
}

//�ж�IP��ַ��������Ƿ�Ϊ����
function IsNum(str)
{
	Reg = /[^0-9]/
	if (!IsEmpty(str)) 
	{
		if (str.toString().match(Reg)){
			return false;
		}
		return true;
	}
	return false;
}
	
 //�ж��Ƿ�Ϊ��Ч��URL��ַ
function IsUrl (str)
{	
	Reg = /^\w{1,4}:\/\/(\w+\.)+\w+(\:\d+)*\/(\w+\/)*(\w+\.{0,}\D{1,4}\?)*[\w\=\%\&\-]*$/g;
	
	if (str.match(Reg)){
		return true;
	}
	return 11;
}

//===================����Ϊ����չʾ����
function showMessage(str) {
	alert(str);
	}